![](./assets/website.png)

# Bracket Engineer

A website to generate 3D printable Power Supply brackets.

Built with Manifold 3D and Three.js

Run it with `npm run dev` build with `npm build`. Deployed to Cloudflare Workers.
